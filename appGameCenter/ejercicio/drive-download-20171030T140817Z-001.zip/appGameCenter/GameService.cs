﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class GameService
{ // HAY Q CREAR UNA LISTA DE JUEGOS 
    
    static List<Player> players;
    static public List<Player> Players
    {
        get { return players; }
    }
    static List<Game> games;
    static public List<Game> Games
    {
        get { return games; }
    }
    static Dictionary<Platforms,Rankings>
    public static Game OldGame()
    {
        Game oldestGame = null;
        int year = int.MaxValue;
        
foreach (Game game in games)

        {
            int y = game.ReleaseDate;
            if (year > y)
            {
                oldestGame = game;
                year = y;
            }
        }
        return oldestGame;
    }
    






    public static void Switches2()
    {

        while (true)
        {

            string frase = Console.ReadLine();
            // Add {color}
            // Remove {color}

            // Pasar a minusculas la frase
            frase = frase.ToLower();
            // Trocear para averiguar el comando y el valor
            string[] splitted = frase.Split(' ');
            string comando = splitted[0];
            string valor = "";
            if (splitted.Length > 1)
            {
                valor = splitted[1];
                if(splitted.Length > 2)
                {
                    string valor2 = null;
                    valor2 = splitted[2];
                    valor += valor2 + valor;
                }
              
            }

            switch(comando)
            {
                case "oldest":
                    GameService.OldGame();
                    break;
                case "scorecount {gamename} {rankingName}":
                    //GameService.ScoreCount();
                    break;
                case "gamescountbygenre{gamename}":

                    //GameService.GameGenre();
                    break;
                case "gamesbyplayer":
                    //GameService.GamesByPlayer():
                default:
                    break;
            }
        }
    }
}

